<!DOCTYPE html>
<html>
<head>
	<title>GİRİŞ SAYFASI</title>
	<meta charset="utf-8">
	<link href="login.css" rel="stylesheet">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script>
	$(document).ready(function(){
		$("#giris").click(function(){

			if ($("#eposta").val()==""   ||  $("#sifre").val()==""){
				alert ("Lütfen bilgileri giriniz");
			}else{

			$.post("kontrol.php",
			{
				eposta:$("#eposta").val(),
				sifre:$("#sifre").val()
			},
			function(data,status){
				if(data==1){
					$(location).attr("href","main.php");
				}else{
					alert("Kullanici adınız veya şifreniz yanlış");
				}
			}
		);
		}
	});
});
</script>
</head>
<body>
<img class="avatar"src="img/royal.jpg">
<label class="adminLabel"> Yönetici Girişi</label>
<div class="girisEkrani">
<label class="girisYazi">Giriş için bilgileri doldurunuz</label>
<br> 
<input type="email" id="eposta" placeholder="Eposta">
<br>
<input type="password" id="sifre" placeholder="Şifre">
<br>
<button id="giris">Giriş</button>
<br>
<a href=""><label>Şifremi Unuttum</label></a>
<a href=""><label>Yeni üye olmak için tıklayınız</label></a>
</div>
</body>
</html>
