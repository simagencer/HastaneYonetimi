<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<title>EKLEME İŞLEMİ TAMAMLANDI</title>
</head>
<body>
<button class="form-control btn btn-danger" type="submit"><a href="cagri.php">Çağrı Kaydı Bilgisi</a></button>
</body>
</html>








<?php
$baglanti=mysqli_connect("localhost","root","","2017469022");
	$baglanti->set_charset("utf8");
	$baglanti->query('SET NAMES utf8');

if($baglanti){
if($_POST){
if(strip_tags(trim(isset($_POST["kayit_id"])))){
$kayit_id=$_POST["kayit_id"];
}
if(strip_tags(trim(isset($_POST["adres"])))){
$adres=$_POST["adres"];
}
if(strip_tags(trim(isset($_POST["tarih"])))){
$tarih=$_POST["tarih"];
}
if(strip_tags(trim(isset($_POST["kayit_nedeni"])))){
$kayit_nedeni=$_POST["kayit_nedeni"];
}
if(strip_tags(trim(isset($_POST["hastane_id"])))){
$hastane_id=$_POST["hastane_id"];
}

if(strip_tags(trim(isset($_POST["plaka_no"])))){
$plaka_no=$_POST["plaka_no"];
}


$sorgu=mysqli_query($baglanti,"INSERT INTO cagri_kaydi (kayit_id,adres,tarih,kayit_nedeni,hastane_id,plaka_no) VALUES ('".$kayit_id."','".$adres."','".$tarih."','".$kayit_nedeni."','".$hastane_id."','".$plaka_no."')");
if($sorgu==TRUE){
echo "Kayıt Başarıyla Eklendi";
}else {
echo "Hata:".$sorgu.$baglan->error;
}
mysqli_close($baglanti);
}else{
echo "Veriler Gelmedi";
}

}else {
die("Bağlantı Sağlanamadı");
};

?>
