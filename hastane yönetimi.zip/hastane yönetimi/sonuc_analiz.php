<?php
require'baglan.php';


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <style>
  body{
    background-color: #D7DCE2;
  }
  </style>
</head>
<body>
 <button type="button" class="btn btn-danger btn-sm" style="margin-left: 5px; margin-top: 10px;"><a href="main.php">Geri</a></button>

<div class="container">

<center>
<h4> Toplam Doluluk Oranı En fazla Olan 2 Poliklinik</h4>
<table class="table table-condensed table-bordered table-hover" style="width: 600px; height: 90px; border:2px;">
<thead>
<tr>
<th>Poliklinik Adı</th>
<th>Hasta Sayısı</th>

</tr>
</thead>
<tbody>
<?php 
$baglanti=mysqli_connect("localhost","root","","2017469022");
  $baglanti->set_charset("utf8");
  $baglanti->query('SET NAMES utf8');

$sorgu = $baglanti->query("SELECT poliklinik.poliklinik_ad as ad,COUNT(hasta.hasta_id) as hasta_sayisi
FROM hasta,doktor,poliklinik,tetkik,hasta_tetkik
WHERE hasta.doktor_id=doktor.doktor_id AND doktor.poliklinik_id=poliklinik.poliklinik_id AND hasta.hasta_id=hasta_tetkik.hasta_id AND tetkik.tetkik_id=hasta_tetkik.tetkik_id 
GROUP BY poliklinik.poliklinik_id
ORDER BY hasta_sayisi DESC
LIMIT 2"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$ad=  $sonuc['ad'];
$hasta_sayisi = $sonuc['hasta_sayisi']; 



?>
    
    <tr>
      <td><?php echo $ad; ?></td>
        <td><?php echo $hasta_sayisi; ?></td>
    
        </tr>

<?php 
} 

?>
</div>
</tbody>
</table>
</center>
<center>
<h4>Toplam Doluluk Oranı En az Olan Poliklinik</h4>
<table class="table table-condensed table-bordered table-hover" style="width: 600px; height: 90px; border:2px;">
<thead>
<tr>
<th>Poliklinik Adı</th>
<th>Hasta Sayısı</th>

</tr>
</thead>
<tbody>
<?php 
$baglanti=mysqli_connect("localhost","root","","2017469022");
  $baglanti->set_charset("utf8");
  $baglanti->query('SET NAMES utf8');

$sorgu = $baglanti->query("SELECT poliklinik.poliklinik_ad as ad,COUNT(hasta.hasta_id) as hasta_sayisi
FROM poliklinik,hasta,doktor,tetkik,hasta_tetkik
WHERE poliklinik.poliklinik_id=doktor.poliklinik_id AND doktor.doktor_id=hasta.doktor_id AND hasta.hasta_id=hasta_tetkik.hasta_id AND tetkik.tetkik_id=hasta_tetkik.tetkik_id 
GROUP BY poliklinik.poliklinik_id
HAVING COUNT(hasta.hasta_id)=(SELECT MIN(toplam) from((SELECT COUNT(hasta.hasta_id) as toplam FROM hasta,poliklinik,doktor,tetkik,hasta_tetkik WHERE poliklinik.poliklinik_id=doktor.poliklinik_id AND doktor.doktor_id=hasta.doktor_id AND hasta.hasta_id=hasta_tetkik.hasta_id AND tetkik.tetkik_id=hasta_tetkik.tetkik_id  GROUP BY poliklinik.poliklinik_id) as sonuc))"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$ad=  $sonuc['ad'];
$hasta_sayisi = $sonuc['hasta_sayisi']; 



?>
    
    <tr>
      <td><?php echo $ad; ?></td>
        <td><?php echo $hasta_sayisi; ?></td>
    
        </tr>

<?php 
} 

?>
</div>
</tbody>
</table>
</center>
<br>
<center>
<h4> Toplam en fazla yapılan 2 Tetkik</h4>
<table class="table table-condensed table-bordered table-hover" style="width: 600px; height: 90px; border:2px;">
<thead>
<tr>
<th>Tetkik Adı</th>
<th>Hasta Sayısı</th>

</tr>
</thead>
<tbody>
<?php 
$baglanti=mysqli_connect("localhost","root","","2017469022");
  $baglanti->set_charset("utf8");
  $baglanti->query('SET NAMES utf8');

$sorgu = $baglanti->query("SELECT tetkik.tetkik_ad as ad,COUNT(hasta.hasta_id) as hasta_sayisi
FROM tetkik,hasta_tetkik,hasta
WHERE tetkik.tetkik_id=hasta_tetkik.tetkik_id AND hasta_tetkik.hasta_id=hasta.hasta_id
GROUP BY tetkik.tetkik_id
ORDER BY hasta_sayisi DESC
LIMIT 2"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$ad=  $sonuc['ad'];
$hasta_sayisi = $sonuc['hasta_sayisi']; 



?>
    
    <tr>
      <td><?php echo $ad; ?></td>
        <td><?php echo $hasta_sayisi; ?></td>
    
        </tr>

<?php 
} 

?>
</div>
</tbody>
</table>
</center>
</center>
<center>
<h4> Toplam en az yapılan Tetkik</h4>
<table class="table table-condensed table-bordered table-hover" style="width: 600px; height: 90px; border:2px;">
<thead>
<tr>
<th>Tetkik Adı</th>
<th>Hasta Sayısı</th>

</tr>
</thead>
<tbody>
<?php 
$baglanti=mysqli_connect("localhost","root","","2017469022");
  $baglanti->set_charset("utf8");
  $baglanti->query('SET NAMES utf8');

$sorgu = $baglanti->query("SELECT tetkik.tetkik_ad as ad,COUNT(hasta.hasta_id) as hasta_sayisi
FROM tetkik,hasta_tetkik,hasta
WHERE tetkik.tetkik_id=hasta_tetkik.tetkik_id AND hasta_tetkik.hasta_id=hasta.hasta_id
GROUP BY tetkik.tetkik_id
HAVING COUNT(hasta.hasta_id)=(SELECT MIN(toplam) from ((SELECT COUNT(hasta.hasta_id) as toplam FROM tetkik,hasta_tetkik,hasta WHERE tetkik.tetkik_id=hasta_tetkik.tetkik_id AND hasta_tetkik.hasta_id=hasta.hasta_id
GROUP BY tetkik.tetkik_id) as sonuc))"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$ad=  $sonuc['ad'];
$hasta_sayisi = $sonuc['hasta_sayisi']; 



?>
    
    <tr>
      <td><?php echo $ad; ?></td>
        <td><?php echo $hasta_sayisi; ?></td>
    
        </tr>

<?php 
} 

?>
</div>
</tbody>
</table>

</center>
<br>
<br>
<center>
<h4> Başvurup hizmet alamayan En fazla Poliklinik </h4>
<p style="color: red;">Buna göre karşılaştırma yapılıp, hangi poliklinikten açmamız için adımlar atılsın...</p>
<table class="table table-condensed table-bordered table-hover" id="table_2" style="width: 600px; height: 90px; border:2px;">
<thead>
<tr>
<th>Poliklinik Adı</th>
<th>Hasta Sayısı</th>

</tr>
</thead>
<tbody>
<?php 
$baglanti=mysqli_connect("localhost","root","","2017469022");
  $baglanti->set_charset("utf8");
  $baglanti->query('SET NAMES utf8');

$sorgu = $baglanti->query("SELECT poliklinik_cevap_verilmeyen.poliklinik_adi as ad,COUNT(poliklinik_cevap_verilmeyen.cevap_id) as hasta_sayisi
FROM poliklinik_cevap_verilmeyen
GROUP BY poliklinik_cevap_verilmeyen.poliklinik_id
ORDER BY hasta_sayisi DESC
LIMIT 2"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$ad=  $sonuc['ad'];
$hasta_sayisi = $sonuc['hasta_sayisi']; 



?>
    
    <tr>
      <td><?php echo $ad; ?></td>
        <td><?php echo $hasta_sayisi; ?></td>
    
        </tr>

<?php 
} 

?>
</div>
</tbody>
</table>
</center>
</div>
</center>


<center>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <div id="bar_div"></div>
<script type="text/javascript">
       google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Yıllar', '2018', '2019', '2020'],
          ['10A7132',  165,      938,         522],
          ['10B7135',  135,      1120,        599]
        ]);

        var options = {
          title : 'Çağrı Kaydı Oranları',
          vAxis: {title: 'Oranlar'},
          hAxis: {title: 'Ambulans Plakaları'},
          colors:['red','blue','orange'],
      seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('bar_div'));
        chart.draw(data, options);
      }
  </script>
</center>
<br>
<br>
<center>
      <script type="text/javascript">
       google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Yıllar', '2018', '2019', '2020'],
          ['10A7132',  9,      18,         26],
          ['10B7135',  7,      16,        21]
        ]);

        var options = {
          title : 'Çağrı Kaydı Oranları',
          vAxis: {title: 'Oranlar'},
          hAxis: {title: 'Ambulans Plakaları'},
          colors:['red','blue','orange'],
      seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('bar_div'));
        chart.draw(data, options);
      }
  </script>
  <p style="color: red;">Daha çok hastaya ulaşmak için çalışmalara başlansın...</p>
   <div id="column_div"></div>
  <script type="text/javascript">
     google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Yıllar', '2018', '2019', '2020'],
          ['10A7132',  11,      28,         32],
          ['10B7135',  6,      22,        35]
        ]);

        var options = {
          title : 'Cevap Verilmeyen Çağrı Kaydı Oranları',
          vAxis: {title: 'Oranlar'},
          hAxis: {title: 'Ambulans Plakaları'},
          colors:['red','blue','orange'],
      seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('column_div'));
        chart.draw(data, options);
      }


</script> 
</center>

	
	


</body> 
</html>
</body>
</html>
